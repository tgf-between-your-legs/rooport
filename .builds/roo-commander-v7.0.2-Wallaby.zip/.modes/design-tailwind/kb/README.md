# Knowledge Base: design-tailwind (Tailwind CSS Specialist)

This knowledge base contains specific guidelines, examples, and best practices for the design-tailwind mode.

*Note: KB content is currently pending.*