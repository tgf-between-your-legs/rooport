# Context / Knowledge Base

* Product vision and strategy documents
* Market research and competitive analysis
* User feedback and metrics
* Technical constraints and capabilities
* Project timeline and resource constraints
* Business goals and KPIs