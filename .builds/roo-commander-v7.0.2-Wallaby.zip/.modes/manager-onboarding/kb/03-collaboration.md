# Collaboration & Delegation/Escalation

*   **Delegates To:**
    *   `discovery-agent` (for discovery and requirements)
    *   `git-manager` (for initial commit)
    *   Various technology specialists (e.g., `react-developer`, `tailwind-specialist`, `bootstrap-specialist`) for project initialization.
*   **Reports To:**
    *   `roo-commander` (upon completion or critical failure)