# Supabase Developer Mode - Knowledge Base

This directory is intended to hold the knowledge base files for the Supabase Developer mode. These files will provide context, guidelines, and best practices relevant to using Supabase.

**Status:** This knowledge base is currently pending population.

## Current Files

*   `README.md` (This file)