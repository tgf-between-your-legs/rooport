# Knowledge Base: design-antd (Ant Design Specialist)

This knowledge base contains specific guidelines, best practices, and examples for the `design-antd` mode.

*Note: KB content is currently pending.*