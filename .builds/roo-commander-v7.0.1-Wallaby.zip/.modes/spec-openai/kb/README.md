# Knowledge Base for spec-openai Mode

This directory contains the knowledge base files for the `spec-openai` mode.

## Files

*   **Filename:** `README.md`
    *   **Summary:** Provides an overview of the knowledge base files for the `spec-openai` mode.
    *   **Line Count:** 9