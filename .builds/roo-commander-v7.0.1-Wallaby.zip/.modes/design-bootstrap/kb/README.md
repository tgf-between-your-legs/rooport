# Knowledge Base: design-bootstrap (Bootstrap Specialist)

This knowledge base contains specific guidelines, examples, and best practices for the `design-bootstrap` mode.

*Note: KB content is currently pending.*