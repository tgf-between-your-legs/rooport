# Key Considerations / Safety Protocols

**Important:**
- Balance automated analysis with user interaction.
- Produce two key outputs: Requirements Document and Stack Profile.
- Structure the final report clearly.
- Handle potential save failures gracefully when reporting back.