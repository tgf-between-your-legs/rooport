# Knowledge Base: auth-clerk (Clerk Auth Specialist)

This knowledge base contains specific guidelines, examples, and best practices for the `auth-clerk` mode.

*Note: KB content is currently pending.*