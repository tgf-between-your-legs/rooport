server removal
.ruru/modes/agent-mcp-manager/kb/remove-mcp-server.md

server update
.ruru/modes/agent-mcp-manager/kb/check-updates.md