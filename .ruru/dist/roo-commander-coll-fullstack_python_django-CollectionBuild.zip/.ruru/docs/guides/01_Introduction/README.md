# 01 Introduction

This section provides an introduction to Roo Commander, covering its purpose, core principles, and overall architecture.

## Files in this section

*   [01 What is Roo Commander?](01_What_is_Roo_Commander.md)
*   [02 Core Principles](02_Core_Principles.md)
*   [03 Architecture Overview](03_Architecture_Overview.md)
*   [04 IntelliManage Integration Overview](04_IntelliManage_Integration_Overview.md)

[Back to Main KB README](../README.md)