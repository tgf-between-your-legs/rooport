# 08 Community & Contributing

This section provides information on how to join the Roo Commander community and guidelines for contributing to the project.

## Files in this section

*   [01 Joining the Community](01_Joining_the_Community.md)
*   [02 Contribution Guide](02_Contribution_Guide.md)

[Back to Main KB README](../README.md)