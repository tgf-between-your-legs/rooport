# 04 Understanding Modes

This section explains the concept of Modes in Roo Commander, their roles, the hierarchy, and how to select the appropriate mode for a task.

## Files in this section

*   [01 Mode Roles Hierarchy](01_Mode_Roles_Hierarchy.md)
*   [02 Mode Selection Guide](02_Mode_Selection_Guide.md)
*   [03 Mode Directory Reference](03_Mode_Directory_Reference.md)

[Back to Main KB README](../README.md)