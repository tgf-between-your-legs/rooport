### Documentation

*   More details about project planning system intellimanage (75d7c89)