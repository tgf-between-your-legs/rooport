# Dev Fixer Mode - Knowledge Base

This directory contains the knowledge base files for the Dev Fixer mode.

Currently, the following files are placeholders and require population with specific knowledge:

*   `01-debugging-process.md`
*   `02-common-pitfalls.md`

Please refer to the mode migration workflow or relevant documentation for instructions on populating these files.