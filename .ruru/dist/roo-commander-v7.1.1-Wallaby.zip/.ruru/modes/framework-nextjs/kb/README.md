# Knowledge Base: framework-nextjs (Next.js Developer)

This knowledge base contains specific guidelines, best practices, and examples for the `framework-nextjs` mode.

*Note: KB content is currently pending.*