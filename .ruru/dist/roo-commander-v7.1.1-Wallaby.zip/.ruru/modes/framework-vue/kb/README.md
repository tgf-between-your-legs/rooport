# Knowledge Base: framework-vue (Vue.js Developer)

This knowledge base contains curated information, guidelines, and best practices for the `framework-vue` mode.

**Note:** The knowledge base content is currently being populated. Specific files (e.g., `01-vue-core-concepts.md`) are not yet available.