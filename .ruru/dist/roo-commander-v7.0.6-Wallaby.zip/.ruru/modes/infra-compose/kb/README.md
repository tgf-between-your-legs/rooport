# Infra Compose Mode - Knowledge Base

This directory contains the knowledge base for the `infra-compose` mode.

Currently, the knowledge base is empty. It may be populated in the future with specific guidelines, best practices, or reference materials relevant to this mode.