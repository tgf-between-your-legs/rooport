# Context / Knowledge Base (Optional)

*   `.roo/context/project-onboarding/` needs:
    - `templates/`: Common project templates (gitignore, README, etc.)
    - `tech_stacks/`: Pre-defined technology stack configurations
    - `journal_structure/`: Standard project journal structure templates
    - `initialization_scripts/`: Common project initialization scripts
    - `discovery_templates/`: Templates for discovery and requirements gathering