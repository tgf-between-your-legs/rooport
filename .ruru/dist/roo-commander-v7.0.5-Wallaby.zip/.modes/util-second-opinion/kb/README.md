# Knowledge Base: util-second-opinion

This directory contains the knowledge base for the `util-second-opinion` mode.

## Status

The knowledge base for this mode is currently empty. It may be populated in the future with relevant information, guidelines, or examples specific to the mode's function of providing critical evaluation and alternative perspectives.