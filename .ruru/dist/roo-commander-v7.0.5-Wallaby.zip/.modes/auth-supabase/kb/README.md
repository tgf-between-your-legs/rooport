# Knowledge Base for auth-supabase Mode

This directory contains the knowledge base (KB) files for the `auth-supabase` mode.

## Contents

*   **README.md**: Provides an overview and lists the contents of the knowledge base for the auth-supabase mode. (Line Count: 7)