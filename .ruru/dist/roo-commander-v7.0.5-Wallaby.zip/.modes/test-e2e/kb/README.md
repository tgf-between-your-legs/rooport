# Knowledge Base: test-e2e (E2E Tester)

This knowledge base contains specific guidelines, best practices, and examples for the `test-e2e` (E2E Tester) mode.

*Note: KB content is currently pending.*