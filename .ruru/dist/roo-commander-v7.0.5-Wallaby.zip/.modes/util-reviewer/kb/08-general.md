# General

- [ ] Is the scope of the change appropriate? (Should it be broken down?)
- [ ] Does the code belong in the right place within the codebase?
- [ ] Does the change align with the overall project architecture and goals?