# Knowledge Base: dev-general (General Developer)

This knowledge base contains specific guidelines, examples, and best practices relevant to the `dev-general` mode.

*Note: KB content is currently pending.*