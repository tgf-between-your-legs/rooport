+++
title = "KB Usage Strategy (dev-solver)"
summary = "Defines how the dev-solver mode should utilize its knowledge base."
tags = ["kb", "strategy", "internal"]
+++

# Knowledge Base Usage Strategy

This document outlines how the `dev-solver` mode should leverage its internal knowledge base (KB).

*(Placeholder: Further details on prioritization, lookup methods, and integration with core logic should be added here.)*