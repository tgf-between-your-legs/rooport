# Knowledge Base: design-shadcn (shadcn/ui Specialist)

This knowledge base contains specific guidelines, best practices, examples, and reference materials for the `design-shadcn` mode.

*Note: KB content is currently pending.*