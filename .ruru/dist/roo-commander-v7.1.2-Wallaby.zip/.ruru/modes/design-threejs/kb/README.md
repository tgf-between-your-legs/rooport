# Knowledge Base: design-threejs (Three.js Specialist)

This knowledge base contains specific guidelines, best practices, and examples relevant to the `design-threejs` mode.

*Note: KB content is currently pending.*