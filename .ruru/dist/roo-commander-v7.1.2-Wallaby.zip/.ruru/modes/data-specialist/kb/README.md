# Data Specialist Knowledge Base

This directory contains the knowledge base files for the `data-specialist` mode.

## Status

The knowledge base is currently empty. Files may be added here in the future to provide specific context, guidelines, or examples relevant to the `data-specialist` mode's tasks.