# Knowledge Base: design-animejs (Anime.js Specialist)

This knowledge base contains specific guidelines, best practices, and examples for the `design-animejs` mode.

*Note: KB content is currently pending.*